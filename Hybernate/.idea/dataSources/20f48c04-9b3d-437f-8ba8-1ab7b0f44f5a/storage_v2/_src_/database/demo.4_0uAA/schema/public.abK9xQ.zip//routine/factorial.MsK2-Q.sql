create procedure factorial(IN number integer, OUT result integer)
    language plpgsql
as
$$
    BEGIN
    select fact(number) into result ;
    return ;
end;
$$;

alter procedure factorial(integer, out integer) owner to postgres;

