create view available_books(book_name, author_name, publisher_name, library_name) as
SELECT books.book_name,
       author.author_name,
       publisher.publisher_name,
       library.library_name
FROM books
         JOIN author ON books.author_code = author.author_code
         JOIN publisher ON books.publisher_code = publisher.publisher_code
         JOIN library ON books.library_id = library.library_id
WHERE books.status::text = 'available'::text;

alter table available_books
    owner to postgres;

