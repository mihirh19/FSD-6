create function calculate_employee_book_count()
    returns TABLE(emp_name character varying, book_count integer)
    language plpgsql
as
$$
DECLARE
    emp_id INTEGER;
BEGIN
    FOR emp_id IN SELECT emp_id FROM employeeadd
        LOOP
            RETURN QUERY SELECT emp_name, COUNT(*) AS book_count FROM
                request
                    INNER JOIN employeeadd ON request.emp_id =
                                              employeeadd.emp_id
                         WHERE request.emp_id = emp_id
                         GROUP BY emp_name;
        END LOOP;
END;
$$;

alter function calculate_employee_book_count() owner to postgres;

