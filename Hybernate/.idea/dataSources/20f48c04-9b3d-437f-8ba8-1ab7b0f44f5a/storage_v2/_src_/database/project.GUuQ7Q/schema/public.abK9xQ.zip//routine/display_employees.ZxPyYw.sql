create function display_employees() returns void
    language plpgsql
as
$$
DECLARE
    emp_record employeeadd%ROWTYPE;
    emp_cursor CURSOR FOR SELECT * FROM employeeadd;
BEGIN
    OPEN emp_cursor;
    LOOP
        FETCH emp_cursor INTO emp_record;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Employee ID: %, Name: %', emp_record.emp_id,
            emp_record.emp_name;
    END LOOP;
    CLOSE emp_cursor;
END;
$$;

alter function display_employees() owner to postgres;

