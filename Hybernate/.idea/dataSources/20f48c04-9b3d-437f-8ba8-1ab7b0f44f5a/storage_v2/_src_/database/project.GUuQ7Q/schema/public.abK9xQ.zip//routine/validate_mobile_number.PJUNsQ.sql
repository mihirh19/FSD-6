create function validate_mobile_number() returns trigger
    language plpgsql
as
$$
DECLARE
    mobile_length INTEGER;
BEGIN
    mobile_length := length(NEW.mem_mobile);
    IF (mobile_length != 10) THEN
        RAISE EXCEPTION 'Mobile number must have 10 digits';
    END IF;
    RETURN NEW;
END;
$$;

alter function validate_mobile_number() owner to postgres;

