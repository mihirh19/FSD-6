create function update_book_status() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE books SET status = 'not available' WHERE book_id = NEW.book_id;
    ELSE
        UPDATE books SET status = 'available' WHERE book_id = OLD.book_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function update_book_status() owner to postgres;

