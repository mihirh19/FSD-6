create function insert_request() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request (emp_id) VALUES (NEW.emp_id);
    RETURN NEW;
END;
$$;

alter function insert_request() owner to postgres;

